
package com.mycompany.gamequiz.x;

public class Estrutura {
    void Niveis(){}
    void Temas(){}
}
