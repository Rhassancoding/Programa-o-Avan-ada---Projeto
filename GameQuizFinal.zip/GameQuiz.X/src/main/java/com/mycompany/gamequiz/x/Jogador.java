
package com.mycompany.gamequiz.x;
public interface Jogador {
    
    public void Apelido();
    public void Idade();
   
    
    
}
