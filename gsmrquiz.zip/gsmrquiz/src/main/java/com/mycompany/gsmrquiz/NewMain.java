
package com.mycompany.gsmrquiz;
import java.util.Scanner;
public class NewMain extends Perguntas{

    public static void main(String[] args) {
        System.out.println("\n\t\t----------0_^_0--------\n\t");
        System.out.println(">>>>>Iniciando<<<<<<\nOBS: a opção que achas correto digite!!!");
        
                                                 Perguntas();
      
     
    }    

    private static void Perguntas() { 
        String opcao;
        Scanner value = new Scanner(System.in);
         String Name, Opcao;
        Scanner valueforinput = new Scanner(System.in);
                System.out.println("\n}-oo-{ Entre com o Primeiro nome Abaixo:  }-oo-{  \n");
         Name = valueforinput.nextLine();
        System.out.println(Name + " }-oo-{Escolha uma das opções de nivel de Perguntas para iniciar o quiz!!!}-oo-{\t");
        System.out.println("1.Qual destes passwords foi o mais usado na internet?\n" +
"\n" +
"a)a1b2c3\n" +
"b)adcdef\n" +
"c)123456 \n");
             opcao = value.next();
              if(!"c".equals(opcao)){
                  System.out.println("!!!Tente Novamente!!! SCORE=0");
                  Perguntas();
                  
              }
              if("c".equals(opcao)){
              
                  System.out.println("\nOPa PARABÉNS ALTERNATIVA CORRETA SOCORE=1\n2.O que significa a sigla “www” na internet\n" +
"\n" +
"a)World wide web\n" +
"b)Web World wide\n" +
"c)Web wide World\n");
                  
                  opcao = value.next();
              if(!"a".equals(opcao)){
                  System.out.println("!!!Tente Novamente!!!");
                  Perguntas();
              }
                 if("a".equals(opcao)){
                     System.out.println("\nOPa PARABÉNS ALTERNATIVA CORRETA SOCORE=2\n3.Qual foi o primeiro tweet da história?\n" +
"\n" +
"a)  “Olá, twitter”\n" +
"b)“Olá, mundo”\n" +
"c)“Estou preparando meu twitter”\n");
                 } 
                  opcao = value.next();
              if(!"c".equals(opcao)){
                  System.out.println("!!!Tente Novamente!!!");
                  Perguntas();
              }
                  if("c".equals(opcao)){
                      System.out.println("\nParabens CORRETO SOCORE=3\n 4.Qual foi a primeira rede social da história da Internet?\n" +
"\n" +
"a)Classmate\n" +
"b)MySpace\n" +
"c)Orkut\n");
                      opcao =value.next();
                      if(!"a".equals(opcao)){
                          System.out.println("Infelizmente não foi dessa Vez!!!\n");
                          Perguntas();
                      }
                     if("a".equals(opcao)){
                         System.out.println("\nParabéns boa escolha ÚLTIMA Pergunta SOCORE=4\n 5.Quantos bits cabem em um byte? \n" +
"\n" +
"a)8 bits\n" +
"b)1 bit\n" +
"c)12 bits\n");    
                        opcao = value.next();
                         if(!"a".equals(opcao)){
                             System.out.println("Vish quase lá passou por perto:((\n");     
                             Perguntas();
                            
                             }
                         }
                     }
                      
                  }
                           if("a".equals(opcao)){
                                 System.out.println("'´´'´´\t''´'´'´'´"+ Name +"\tCAMPEÃO'´'´'´\t'´'´'´´'");
                                java.awt.EventQueue.invokeLater(new Runnable() {
                                  public void run() {
                           new NewJFrame();
            }
        });
            }
    }
}
