
package com.mycompany.gsmrquiz;

public class Perguntas {
    public Perguntas(){
        System.out.println("O que é o que é que cai em pe e corre deitado?");
        
    }
}
